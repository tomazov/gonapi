// /main.go
package main

import "napi/cmd/server"

func main() {
	server.Run()
}
