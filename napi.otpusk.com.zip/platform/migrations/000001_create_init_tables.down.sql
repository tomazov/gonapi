-- Delete tables
DROP TABLE IF EXISTS books;